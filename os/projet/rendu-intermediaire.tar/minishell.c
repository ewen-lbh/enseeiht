#define _POSIX_SOURCE
#include "readcmd.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h> /* wait */

struct job
{
    int pid;
    char *command;
    bool running;
};

static struct job jobs[999];
static bool got_sigchild_from_job = false;

int index_by_pid(int pid)
{
    for (int i = 0; i < 999; i++)
    {
        if (jobs[i].pid == pid)
        {
            return i;
        }
    }
    return -1;
}

char *join_strings(char **strings, char join_by)
{
    int total_length = 0;
    for (int i = 0; strings[i] != NULL; i++)
    {
        total_length += strlen(strings[i]) + 1;
    }
    total_length--; // pas de joiner à la fin

    char *result = malloc(sizeof(char) * (total_length + 1) + 1);

    for (int i = 0; strings[i] != NULL; i++)
    {
        strcat(result, strings[i]);
        if (strings[i + 1] != NULL)
        {
            char join_by_str[2] = {join_by};
            strcat(result, join_by_str);
        }
    }
    result[total_length] = '\0';

    return result;
}

void sigchild_handler()
{
    int child_pid = waitpid(-1, NULL, WNOHANG);
    while (child_pid > 0)
    {
        int job_index = index_by_pid(child_pid);
        if (job_index != -1)
        {
            jobs[job_index].running = false;
        }
        child_pid = waitpid(-1, NULL, WNOHANG);
    }
    got_sigchild_from_job = true;
}

int main()
{
    int code_term;
    int last_job = -1;

    signal(SIGCHLD, &sigchild_handler);

    while (true)
    {
        printf("🐚 ");
        struct cmdline *commandline;
        commandline = readcmd();

        if (commandline == NULL)
        {
            if (got_sigchild_from_job)
            {
                got_sigchild_from_job = false;
                printf("\r\033[K"); // clear la ligne et remettre le curseur au début, pour éviter de print deux fois le prompt
                continue;
            }
            else
            {
                break;
            }
        }

        // pour l'instant on ne traite pas les pipelines, donc on prend que le premier élément de ***seq
        char **args = commandline->seq[0];

        if (strcmp(args[0], "exit") == 0)
        {
            break;
        }

        if (strcmp(args[0], "cd") == 0)
        {
            chdir(args[1]);
            continue;
        }

        if (strcmp(args[0], "lj") == 0)
        {
            for (int i = 0; i <= last_job; i++)
            {
                printf("💼 %d (%d) %s", i + 1, jobs[i].pid, jobs[i].command);
                if (!jobs[i].running)
                {
                    printf(" (stopped)");
                }
                printf("\n");
            }
            continue;
        }

        if (strcmp(args[0], "sj") == 0)
        {
            int job_index = atoi(args[1]) - 1;
            if (job_index > last_job)
            {
                printf("ECHEC: job %d does not exist\n", job_index + 1);
                continue;
            }
            if (kill(jobs[job_index].pid, SIGSTOP) == -1)
            {
                printf("ECHEC: could not send SIGCONT to job %d\n", job_index + 1);
                continue;
            }
            jobs[job_index].running = false;
            continue;
        }

        if (strcmp(args[0], "bg") == 0)
        {
            int job_index = atoi(args[1]) - 1;
            if (job_index > last_job)
            {
                printf("ECHEC: job %d does not exist\n", job_index + 1);
                continue;
            }
            if (kill(jobs[job_index].pid, SIGCONT) == -1)
            {
                printf("ECHEC: could not send SIGCONT to job %d\n", job_index + 1);
                continue;
            }
            jobs[job_index].running = true;
            continue;
        }

        if (strcmp(args[0], "fg") == 0)
        {
            int job_index = atoi(args[1]) - 1;
            if (!jobs[job_index].running)
            {
                kill(jobs[job_index].pid, SIGCONT);
                jobs[job_index].running = true;
            }
            int code_term_fj;
            waitpid(jobs[job_index].pid, &code_term_fj, 0);
            if (!WIFEXITED(code_term))
            {
                printf("ECHEC: child did not exit (was killed by a signal)\n");
            }
            if (WEXITSTATUS(code_term) != EXIT_SUCCESS)
            {
                printf("💀 %d\n", WEXITSTATUS(code_term));
            }
        }

        int child_pid = fork();
        if (child_pid == -1)
        {
            printf("ECHEC: could not fork\n");
        }
        else if (child_pid == 0)
        {
            if (execvp(args[0], args) != 0)
            {
                exit(EXIT_FAILURE);
            }
        }
        else
        {
            if (commandline->backgrounded)
            {
                struct job *new_job = malloc(sizeof(struct job));
                new_job->pid = child_pid;
                new_job->running = true;
                // char *full_command = join_strings(args, ' ');
                // new_job->command = malloc(sizeof(char) * (strlen(full_command) + 1));
                new_job->command = malloc(sizeof(char) * strlen(args[0]) + 1);
                strcpy(new_job->command, args[0]);
                jobs[++last_job] = *new_job;
                free(new_job);
                printf("💤️ %d (%d)\n", last_job + 1, child_pid);
            }
            else
            {
                waitpid(child_pid, &code_term, 0);
                if (!WIFEXITED(code_term))
                {
                    printf("ECHEC: child did not exit (was killed by a signal)\n");
                }
                if (WEXITSTATUS(code_term) != EXIT_SUCCESS)
                {
                    printf("💀 %d\n", WEXITSTATUS(code_term));
                }
            }
        }
    }

    for (int i = 0; i < last_job; i++)
    {
        free(jobs[i].command);
    }

    return EXIT_SUCCESS; /* -> exit(EXIT_SUCCESS); pour le père */
}
