make test
./table_test
./parsing_test
./routeur_simple_test
